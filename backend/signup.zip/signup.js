const AWS = require("aws-sdk");
const bcrypt = require("bcryptjs");
const uuid = require("uuid");
const dynamoDB = new AWS.DynamoDB.DocumentClient();

exports.handler = async (event) => {
  console.log("event=>", event);
  console.log(
    "event.name",
    "event.email",
    "event.passsword",
    event.name,
    event.email,
    event.password
  );
  if (!event.name || !event.email || !event.password) {
    return {
      statusCode: 400,
      body: JSON.stringify({ message: "All fields are required." }),
    };
  }

  try {
    const params = {
      TableName: "Users",
      Key: {
        email: event.email,
      },
    };

    const existingUser = await dynamoDB.get(params).promise();

    if (existingUser.Item) {
      return {
        statusCode: 400,
        body: JSON.stringify({ message: "User already exists." }),
      };
    }

    const putParams = {
      TableName: "Users",
      Item: event,
    };

    await dynamoDB.put(putParams).promise();

    return {
      statusCode: 200,
      body: JSON.stringify({
        message: "User registered successfully.",
        user: { email: event.email, name: event.name },
      }),
    };
  } catch (error) {
    console.log("Error saving user:", error);
    return {
      statusCode: 500,
      body: JSON.stringify({ message: "Error creating user." }),
    };
  }
};
